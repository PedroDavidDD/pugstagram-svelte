<style>
  .Footer {
    font-size: 11px;
    letter-spacing: 1px;
    font-weight: normal;
    color: #c7c7c7;
  }
</style>

<div class="Footer">
  <div class="Footer-container">
    <div class="Footer-copy">© 2020 PUGSTAGRAM FROM PLATZI</div>
  </div>
</div>
